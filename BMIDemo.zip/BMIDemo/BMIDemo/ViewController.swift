//
//  ViewController.swift
//  BMIDemo
//
//  Created by Allam,Shiva Kumar on 4/10/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var heightOutlet: UITextField!
    
    
    @IBOutlet weak var weightOutlet: UITextField!
    
    var r = 0.00
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func bmiButton(_ sender: Any) {
        var h = Double(heightOutlet.text!)
        var w = Double(weightOutlet.text!)
        r = w!/(h!*h!)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var tansition=segue.identifier
        if tansition=="ResultSegue"{
            var destination=segue.destination as! ResultViewController
            destination.resultFromScreen1=r
        }
    }
    
    

}

