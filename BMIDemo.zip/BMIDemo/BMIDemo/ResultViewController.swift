//
//  ResultViewController.swift
//  BMIDemo
//
//  Created by Allam,Shiva Kumar on 4/10/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var resultShowOL: UILabel!
    
    
    @IBOutlet weak var displayImage: UIImageView!
    
    var resultFromScreen1:Double = 0.0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        resultShowOL.text = String(resultFromScreen1)
        if(resultFromScreen1>1){
            displayImage.image = UIImage(named: "sai")
        }
        else{
            displayImage.image = UIImage(named: "jahnavi")
        }

    }
    
    @IBAction func shakeME(_ sender: Any) {
        var width = displayImage.frame.width
               
               width += 40
               
               var height = displayImage.frame.height
               
               height = height + 40
               
               var x  =  displayImage.frame.origin.x-20
               
               
               var y = displayImage.frame.origin.y-20
               
               var largeFrame = CGRect(x: x, y: y, width: width, height: height)
               
               UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
                   self.displayImage.frame = largeFrame
               })
        
    }
    

}
