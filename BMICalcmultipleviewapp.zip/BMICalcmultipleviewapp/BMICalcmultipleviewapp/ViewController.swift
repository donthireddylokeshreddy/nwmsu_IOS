//
//  ViewController.swift
//  BMICalcmultipleviewapp
//
//  Created by Krishnamaneni,Divya on 4/8/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var InchesOutlet: UITextField!
    @IBOutlet weak var FeetOutlet: UITextField!
    
    @IBOutlet weak var EnterweightOutlet: UITextField!
    var BMI = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func Calculatebtn(_ sender: Any) {
       
        var nd:Double
        var hfeet:Double = Double(FeetOutlet.text!)!
        var hinche:Double = Double(InchesOutlet.text!)!
        var wght = Double(EnterweightOutlet.text!)
        nd = (hfeet * 12) + hinche
        BMI = round((703 * ((wght)!/(nd*nd)))*10.0)/10.0
        
        
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var trasition = segue.identifier
        if trasition == "ResultSegue"{
            var destination = segue.destination as! ResultViewController
            destination.result = String(BMI)
            destination.bmivalue = BMI
            
            
        
            
        }
    }
}

