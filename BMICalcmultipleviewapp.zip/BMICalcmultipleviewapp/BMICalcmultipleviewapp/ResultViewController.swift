//
//  ResultViewController.swift
//  BMICalcmultipleviewapp
//
//  Created by Krishnamaneni,Divya on 4/8/23.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var Imageview: UIImageView!
    @IBOutlet weak var BMIlabelOutlet: UILabel!
    
    @IBOutlet weak var dispalylabel: UILabel!
    var result = ""
    var bmivalue: Double?
    
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
      BMIlabelOutlet.text = BMIlabelOutlet.text! + result
        if let bmi = bmivalue {
                    dispalylabel.text = "\(bmi)"
            if bmi <= 18.5 {
                dispalylabel.text = "Your body mass index is \(bmi).\nThis is Considered Underweight."
                Imageview.image = UIImage(named: "underWeight")
                
            }
            else if(bmi >= 18.6 && bmi <= 24.9){
                dispalylabel.text = "Your body mass index is \(bmi).\nThis is Considered Normal."
                Imageview.image = UIImage(named: "normal")
            }
            else if(bmi >= 25 && bmi <= 29.9){
                dispalylabel.text = "Your body mass index is \(bmi).This is Considered OverWeight."
                Imageview.image = UIImage(named: "overWeight")
            }
            else if(bmi >= 30){
                dispalylabel.text = "Your body mass index is \(bmi).This is Considered Obesity."
                Imageview.image = UIImage(named: "obese")
            }
                }
        animateImage()
        
        
        
            
        
    

        // Do any additional setup after loading the view.
    }
    func animateImage() {
            UIView.animate(withDuration: 1.0, delay: 0.0, options: [.repeat, .autoreverse], animations: {
                self.Imageview.frame.origin.y += 20.0
            }, completion: nil)
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
