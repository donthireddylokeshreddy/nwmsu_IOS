//
//  ViewController.swift
//  Donthireddy_CalculatorApp
//
//  Created by Donthireddy,Lokeshreddy on 2/16/23.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
    }
    var operand1 = 0.0
    var operand2 = 0.0
    var operators = "+"
    var result = 0.0
    var final = 0
    
    
    @IBOutlet weak var resultOutlet: UILabel!
    @IBAction func buttonAC(_ sender: UIButton) {
        resultOutlet.text = ""
    }
    
    @IBAction func buttonC(_ sender: UIButton) {
        var res = resultOutlet.text!
        if res.count > 0{
            resultOutlet.text!.removeLast();
        }
    }
    
    @IBAction func buttonSign(_ sender: UIButton) {
        if operators == "+"{
            operators = "-"
        }
        else {
            operators =  "+"
        }
    }
    
    @IBAction func buttonDiv(_ sender: UIButton) {
        operand1 = Double(resultOutlet.text!)!
        operators = "/"
        resultOutlet.text! = ""
    }
    
    @IBAction func buttonMul(_ sender: UIButton) {
        operand1 = Double(resultOutlet.text!)!
                operators = "*"
                resultOutlet.text! = ""
    }
    
    @IBAction func buttonMinus(_ sender: UIButton) {
        operand1 = Double(resultOutlet.text!)!
                operators = "-"
                resultOutlet.text! = ""
    }
    
    @IBAction func buttonPlus(_ sender: UIButton) {
        operand1 = Double(resultOutlet.text!)!
                operators = "+"
                resultOutlet.text! = ""
    }
    
    @IBAction func buttonDot(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + ".";
    }
    
    @IBAction func buttonRem(_ sender: UIButton) {
        operand1 = Double(resultOutlet.text!)!
                operators = "%"
                resultOutlet.text! = ""
    }
    
    @IBAction func buttonEqual(_ sender: UIButton) {
        operand2 = Double(resultOutlet.text!)!
                if operators == "+" {
                    final = Int(operand1 + operand2)
                    resultOutlet.text = String(final)
                }
                else if operators == "-" {
                    final = Int(operand1 - operand2)
                    resultOutlet.text = String(final)
                }
                else if operators == "/"{
                    result = operand1 / operand2
                    result = round(result * 100000) / 100000.0
                    resultOutlet.text = String(result)
                    if(operand2 == 0){
                        resultOutlet.text! = "Not a number"
                    }
                }
                else if operators == "*"{
                    final = Int(operand1 * operand2)
                    resultOutlet.text = String(final)
                }
                else if operators == "%"{
                    result = operand1.truncatingRemainder(dividingBy: operand2)
                    result = round(result * 10) / 10.0
                    resultOutlet.text = String(result)
                }
    }
    
    @IBAction func buttonZero(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "0";
    }
    
    @IBAction func buttonOne(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "1";
    }
    @IBAction func buttonTwo(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "2";
    }
    @IBAction func buttonThree(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "3";
    }
    @IBAction func buttonFour(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "4";
    }
    @IBAction func buttonFive(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "5";
    }
    @IBAction func buttonSix(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "6";
    }
    @IBAction func buttonSeven(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "7";
    }
    @IBAction func buttonEight(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "8";
    }
    @IBAction func buttonNine(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "9";
    }
    
}
