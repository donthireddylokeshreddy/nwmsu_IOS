//
//  ViewController.swift
//  Donthireddy_assignment01
//
//  Created by Donthireddy,Lokeshreddy on 2/2/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var OutletFirstname: UITextField!
    
    @IBOutlet weak var OutletLastname: UITextField!
    
    @IBOutlet weak var OutletDOB: UITextField!
    
    @IBOutlet weak var firstnameoutlet: UILabel!
    
    @IBOutlet weak var ageoutlet: UILabel!
    
    
    @IBOutlet weak var lastnameoutlet: UILabel!
    
    @IBOutlet weak var detailslabel: UILabel!
    
    @IBOutlet weak var fullNamelabel: UILabel!
    
    @IBOutlet weak var initialslabel: UILabel!
    
    
    @IBOutlet weak var agelabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        super.view.backgroundColor=UIColor.systemTeal
    }
    
    @IBAction func SubmitBTN(_ sender: Any) {
        detailslabel.text="Details"
        let firstname = OutletFirstname.text ?? ""
        let lastname = OutletLastname.text ?? ""
        let fullName = "\(lastname)"+" "+"\(firstname)"
        fullNamelabel.text = "Full Name : "+fullName
        let initials = String(firstname.prefix(1)+lastname.prefix(1))
        initialslabel.text="Initals : "+initials
        let byear = Int(OutletDOB.text ?? "0") ?? 0
        var age = 2023-Int(byear)
        agelabel.text="Age : "+"\(age)"
    }
    
    @IBAction func ResetBTN(_ sender: Any) {
        OutletFirstname.text=""
        OutletLastname.text=""
        OutletDOB.text=""
        detailslabel.text=""
        fullNamelabel.text=""
        initialslabel.text=""
        agelabel.text=""
        
    }
    


}

