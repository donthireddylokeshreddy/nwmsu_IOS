//
//  ViewController.swift
//  Donthireddy_SearchApp
//
//  Created by Donthireddy,Lokeshreddy on 3/23/23.
//

import UIKit

class ViewController: UIViewController {

    var Image  = 0
    var topic  = 0
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var searchOL: UIButton!
    @IBOutlet weak var resetOL: UIButton!
    @IBOutlet weak var nextOL: UIButton!
    
    @IBOutlet weak var prevOL: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        Image = 0;
               topic = 0;
        prevOL.isHidden = true
                resetOL.isHidden = true
                nextOL.isHidden = true
                searchTextField.text = ""
        searchOL.isEnabled = false
                resultImage.image = UIImage(named: "welcome")
                topicInfoText.isHidden = true
    }
var vehicle_keywords=["transport","journey","vehicle","travel"]
    var country_keywords=["flag","country","place"]
    var app_keywords=["socialmedia","entertainment","app"]
    var arr=[["vehicle1","vehicle2","vehicle3","vehicle4","vehicle5"],["country1","country2","country3","country4","country5"],["app1","app2","app3","app4","app5"]]
    var topics_array=[["Cars are a mode of transportation that are designed for personal use, typically accommodating up to five passengers. They have become an essential part of modern society, providing convenience and freedom of movement to millions of people worldwide","Bikes, also known as bicycles, are human-powered vehicles consisting of a frame, two wheels, and pedals. They are a popular mode of transportation and recreation, providing a low-cost and environmentally friendly alternative to cars and other motorized vehicles.","Trains are a mode of transportation that run on tracks and can carry passengers and cargo. They have been a key part of global transportation infrastructure for over two centuries, allowing for efficient movement of goods and people across long distances.","Ships are large vessels that travel on water and are used for transportation of goods and people across oceans, seas, and rivers. They have played a crucial role in global trade and travel for centuries, makin","Aeroplanes, also known as airplanes, are vehicles that use wings and jet engines to fly through the air. They are a fast and efficient mode of transportation, connecting people and goods across the world in a matter of hours."],["ndia is a country located in South Asia, bordered by the Bay of Bengal, Arabian Sea, and the Himalayan mountain range. It is known for its rich cultural heritage, diverse population, and vibrant traditions.","ndia is a country located in South Asia, bordered by the Bay of Bengal, Arabian Sea, and the Himalayan mountain range. It is known for its rich cultural heritage, diverse population, and vibrant traditions.","The United Kingdom, also known as the UK, is a country located in Europe, bordered by the Atlantic Ocean, North Sea, English Channel, and the Irish Sea. It is known for its rich history, diverse cultural heritage, and as a global center for finance, education, and culture.","China is a country located in East Asia, bordered by the Pacific Ocean, Russia, Mongolia, Kazakhstan, Kyrgyzstan, Tajikistan, Afghanistan, Pakistan, India, Nepal, Bhutan, Myanmar, Laos, and Vietnam. It is the world's most populous country and is known for its rich cultural heritage, rapidly growing economy, and technological advancements.","Pakistan is a country located in South Asia, bordered by India to the east, Afghanistan and Iran to the west, China to the north, and the Arabian Sea to the south. It is known for its diverse geography, rich cultural heritage, and for being the world's first Islamic republic."],["Twitter is a social media platform that allows users to share short messages, known as tweets, with their followers. It has become a popular platform for news, opinions, and real-time conversations, with millions of users around the world.","WhatsApp is a messaging application that allows users to send text messages, make voice and video calls, and share files with individuals or groups. It has become a popular platform for communication among friends, family, and colleagues, with over 2 billion users worldwide.","Facebook is a social networking platform that allows users to connect with friends, family, and colleagues, share updates, photos, and videos, and join groups and communities of interest. It has become a ubiquitous platform for social interaction and digital marketing, with over 2.8 billion monthly active users as of 2021.","Instagram is a social media platform that allows users to share photos, videos, and short messages with their followers. It has become a popular platform for influencers, businesses, and individuals to showcase their visual content and engage with their audience, with over 1 billion monthly active users as of 2021.","YouTube is a video-sharing platform that allows users to upload, share, and view videos. It has become a popular source of entertainment, education, and information, with millions of creators and viewers around the world."]]
    @IBAction func searchButtonAction(_ sender: UIButton) {
        
        if(vehicle_keywords.contains(searchTextField.text!.lowercased())) {
            topic = 1
        }
        else if(country_keywords.contains(searchTextField.text!.lowercased())) {
            topic = 2
        }
        else if(app_keywords.contains(searchTextField.text!.lowercased())) {
            topic = 3
        }
        else {
            topic = 0
        }
        if(topic > 0) { 
            prevOL.isHidden = false
            resetOL.isHidden = false
            nextOL.isHidden = false
            prevOL.isEnabled = false
            nextOL.isEnabled = true
            topicInfoText.isHidden = false
            Image = 0
            resultImage.image = UIImage(named: arr[topic-1][0])
            topicInfoText.text = topics_array[topic-1][0]
        }
        else {
            
            prevOL.isHidden = true
            resetOL.isHidden = true
            nextOL.isHidden = true
            topicInfoText.isHidden = true
            Image = 0
            resultImage.image = UIImage(named: "nodata")
            
        }
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
        Image = Image+1
                resultImage.image = UIImage(named: arr[topic-1][Image])
                topicInfoText.text = topics_array[topic-1][Image]
                prevOL.isHidden = false;
                resetOL.isHidden = false
                nextOL.isHidden=false
                prevOL.isEnabled = true
                if(Image>3) {
                    nextOL.isEnabled = false
                    
                }
    }
    @IBAction func ResetBtn(_ sender: UIButton) {
        Image = 0;
               topic = 0;
                prevOL.isHidden = true
                resetOL.isHidden = true
                nextOL.isHidden = true
                searchTextField.text = ""
                searchOL.isEnabled = false
                resultImage.image = UIImage(named: "welcome")
                topicInfoText.isHidden = true
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
        Image=Image-1
                resultImage.image = UIImage(named: arr[topic-1][Image])
                topicInfoText.text = topics_array[topic-1][Image]
                nextOL.isEnabled = true
                prevOL.isHidden = false;
                resetOL.isHidden = false
                nextOL.isHidden=false
                if(Image==0) {
                    prevOL.isEnabled = false
                }
    }
    
   
    @IBAction func emnableSearch(_ sender: Any) {
        searchOL.isEnabled = true
    }
    
}

