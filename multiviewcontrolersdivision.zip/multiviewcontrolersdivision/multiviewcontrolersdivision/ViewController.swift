//
//  ViewController.swift
//  multiviewcontrolersdivision
//
//  Created by Donthireddy,Lokeshreddy on 4/3/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var num1: UITextField!
    
    @IBOutlet weak var num2: UITextField!
    
    var sum = ""
    var afteradding = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func calculate(_ sender: Any) {
        var one = Double(num1.text!)
        var two = Double(num2.text!)
        print(calculate)
        afteradding = one!/two!
        print(afteradding)
        
        
    }
    override func prepare(for Segue: UIStoryboardSegue, sender: Any?) {
        var transition = Segue.identifier
        if transition == "resultSegue"{
            var destination = Segue.destination as! resultViewController
            destination.onenumscreenone = num1.text!
            destination.twonumscreenone = num2.text!
            destination.resultfromscrrenone = String(afteradding)
        }
    }
}


