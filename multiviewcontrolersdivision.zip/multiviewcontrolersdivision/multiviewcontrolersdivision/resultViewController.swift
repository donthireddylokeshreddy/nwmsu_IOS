//
//  resultViewController.swift
//  multiviewcontrolersdivision
//
//  Created by Donthireddy,Lokeshreddy on 4/3/23.
//

import UIKit

class resultViewController: UIViewController {
    
    
    @IBOutlet weak var enterednum1: UILabel!
    
    @IBOutlet weak var enterednum2: UILabel!
    
    
    @IBOutlet weak var result: UILabel!
    
    var onenumscreenone = ""
    var twonumscreenone = ""
    var resultfromscrrenone = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        enterednum1.text="enterednumber1:"+onenumscreenone
        enterednum2.text="enterednumber2:"+twonumscreenone
        
        result.text=resultfromscrrenone
        
    }
    

    

}
