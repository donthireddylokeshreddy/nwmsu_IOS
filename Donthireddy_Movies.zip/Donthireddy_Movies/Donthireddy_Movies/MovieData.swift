//
//  MovieData.swift
//  Donthireddy_Movies
//
//  Created by Donthireddy,Lokeshreddy on 4/28/23.
//
import Foundation
import UIKit
struct Movie {
    var title : String
    var image : UIImage
    var releasedYear : String
    var movieRating : String
    var boxOffice : String
    var moviePlot : String
    var cast : [String] = []

}
struct Genre {
    var category : String
    var movies : [Movie] = []
}

var movielist1 =
    Genre(category: "Historical", movies: [
        Movie(title: "Schindler's List", image: UIImage(named: "schindlers-list")!, releasedYear: "1993", movieRating: "8.9", boxOffice: "$321.2 M", moviePlot: "In German-occupied Poland during World War II, industrialist Oskar Schindler gradually ", cast: ["Liam Neeson", "Ben Kingsley"]),
        Movie(title: "Braveheart", image: UIImage(named: "braveheart")!, releasedYear: "1995", movieRating: "8.3", boxOffice: "$210.4 M", moviePlot: "When his secret bride is executed for assaulting an English soldier.", cast: ["Mel Gibson", "Sophie"]),
        Movie(title: "Gone with the Wind", image: UIImage(named: "gone-with-the-wind")!, releasedYear: "1939", movieRating: "8.1", boxOffice: "$390.5 M", moviePlot: "A manipulative woman and a roguish man conduct a turbulent romance during the American Civil War and Reconstruction periods.", cast: ["Clark Gable","Vivien Leigh"]),
        Movie(title: "Saving Private Ryan", image: UIImage(named: "saving-private-ryan")!, releasedYear: "1998", movieRating: "8.6", boxOffice: "$481.8 M", moviePlot: "Following the Normandy Landings, a group of US soldiers go behind enemy lines to retrieve a paratrooper whose brothers have been killed in action.", cast: ["Tom Hanks","Matt Damon"]),
        Movie(title: "The King's Speech", image: UIImage(named: "the-kings-speech")!, releasedYear: "2010", movieRating: "8.0", boxOffice: "$427.4 M", moviePlot: "The story of King George VI, his impromptu ascension to the throne of the British ", cast: ["Colin Firth", "Geoffrey Rush"])
    ])



var movielist2 =
    Genre(category: "Horror", movies: [
        Movie(title: "The Shining", image: UIImage(named: "the-shining")!, releasedYear: "1980", movieRating: "8.4", boxOffice: "$44.4 M", moviePlot: "A family heads to an isolated hotel for the winter where an evil  past and future.", cast: ["Jack Nicholson", "Shelley Duvall"]),
        Movie(title: "Get Out", image: UIImage(named: "get-out")!, releasedYear: "2017", movieRating: "7.7", boxOffice: "$255.4 M", moviePlot: "A young African-American visits his white girlfriend's parents for the weekend.", cast: ["Daniel Kaluuya", "Allison Williams"]),
        Movie(title: "Hereditary", image: UIImage(named: "hereditary")!, releasedYear: "2018", movieRating: "7.3", boxOffice: "$80.2 M", moviePlot: "A grieving family is haunted by tragic and disturbing occurrences.", cast: ["Toni Collette", "Milly Shapiro"]),
        Movie(title: "The Conjuring", image: UIImage(named: "the-conjuring")!, releasedYear: "2013", movieRating: "7.5", boxOffice: "$319.5 M", moviePlot: "Paranormal investigators Ed and Lorraine Warren work to help a family terrorized by a dark presence in their farmhouse.", cast: ["Vera Farmiga", "Patrick Wilson"]),
        Movie(title: "Psycho", image: UIImage(named: "psycho")!, releasedYear: "1960", movieRating: "8.5", boxOffice: "$50.2 M", moviePlot: "A Phoenix secretary embezzles ", cast: ["Anthony Perkins", "Janet Leigh"])
    ])

var movieList3 =
    Genre(category: "Drama", movies: [
        Movie(title: "umamaheshwara", image: UIImage(named: "Umamaheshwara")!, releasedYear: "2010", movieRating: "5.2", boxOffice: "$100.9 M", moviePlot: "uma maheswara ugra roopasya movie ", cast: ["maha venkatesh", "Roopa"]),
        Movie(title: "ps2", image: UIImage(named: "ps2")!, releasedYear: "2020", movieRating: "7.8", boxOffice: "$527.4 M", moviePlot: "vandiyathevan sets out to cross the chola land to deliver a message from the crown prince aditha karikalan.", cast: ["aishwarya ari", "trisha"]),
        Movie(title: "Sillifellows", image: UIImage(named: "Sillifellows")!, releasedYear: "2018", movieRating: "5.3", boxOffice: "$82.3 M", moviePlot: "An influential politician on his deathbed reveals the whereabouts ", cast: ["chitra", "nandini"]),
        Movie(title: "bhathaludu", image: UIImage(named: "bhathaludu")!, releasedYear: "2018", movieRating: "5.6", boxOffice: "$355.1 M", moviePlot: "A hugely successful businessman decides to celebrate his birthday ", cast: ["nari", "charuhasan"]),
        Movie(title: "poks", image: UIImage(named: "poks")!, releasedYear: "2018", movieRating: "9.0", boxOffice: "$0.4 B", moviePlot: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, ", cast: ["mahendra", "chitra"])
    ])

var movieCollect = [movielist1,movielist2,movieList3]
