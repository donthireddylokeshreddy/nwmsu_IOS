//
//  MovieCollectionViewCell.swift
//  Donthireddy_Movies
//
//  Created by Donthireddy,Lokeshreddy on 4/28/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var MovieImzageOutlet: UIImageView!
    func assignMovies(im : Movie) {
        MovieImzageOutlet.image = im.image
    }
}
