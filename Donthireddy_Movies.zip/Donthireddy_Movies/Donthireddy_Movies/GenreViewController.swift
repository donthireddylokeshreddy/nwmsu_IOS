//
//  ViewController.swift
//  Donthireddy_Movies
//
//  Created by Donthireddy,Lokeshreddy on 4/28/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movieCollect.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = genreTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        cell.textLabel?.text = movieCollect[indexPath.row].category
        return cell
    }
    

    @IBOutlet weak var genreTableView: UITableView!
    var Genres = movieCollect
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Movies App"
        genreTableView.delegate = self
        genreTableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if(transition=="movieSegue") {
            var destination = segue.destination as! MoviesViewController
            destination.MovieData = movieCollect[(genreTableView.indexPathForSelectedRow?.row)!].movies
        }
    }


}


