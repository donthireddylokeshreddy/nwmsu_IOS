//
//  BeachViewController.swift
//  Donthireddy_Exam03
//
//  Created by Donthireddy,Lokeshreddy on 4/27/23.
//

import UIKit

class BeachViewController: UIViewController {

    var bName=""
    var bImage=""
    
    
    @IBOutlet weak var beachName: UILabel!
    
    
    @IBOutlet weak var beachImage: UIImageView!
    
   
    @IBAction func animateBeach(_ sender: Any) {
        
        UIView.animate(withDuration: 2, delay:0, animations: {
                            self.beachImage.alpha = 0
                        })
                        UIView.animate(withDuration: 2, delay:0, animations: {
                            self.beachImage.alpha = 1
                        })
     }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        beachName.text = bName
        beachImage.image = UIImage(named: bImage)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
