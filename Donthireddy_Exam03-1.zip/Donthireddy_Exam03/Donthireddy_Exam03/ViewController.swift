//
//  ViewController.swift
//  Donthireddy_Exam03
//
//  Created by Donthireddy,Lokeshreddy on 4/27/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return beaches.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create a cell
        let myCell = beachTableView.dequeueReusableCell(withIdentifier: "beachCell", for: indexPath)
        //popolate a cell with data
        myCell.textLabel?.text = beaches[indexPath.row].name
        //return a cell
        return myCell
    }
    
    
    
    
    
    @IBOutlet weak var beachTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        beachTableView.delegate=self
        beachTableView.dataSource=self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "beachSegue"{
            var destination=segue.destination as! BeachViewController
            destination.bName=beaches[(beachTableView.indexPathForSelectedRow?.row)!].name
            destination.bImage=beaches[(beachTableView.indexPathForSelectedRow?.row)!].image
        }
        
    }
    
}
