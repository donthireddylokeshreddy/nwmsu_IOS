//
//  BeachData.swift
//  Donthireddy_Exam03
//
//  Created by Donthireddy,Lokeshreddy on 4/27/23.
//

import Foundation

struct Beach {
    var name: String
    var image: String
}

let beaches = [
    Beach(name: "Glass Beach", image:"image1"),
    Beach(name: "Pink Sand Beach", image:"image2"),
    Beach(name: "Black Sand Beach",  image:"image3"),
    Beach(name: "Hyams Beach",  image:"image4"),
    Beach(name: "Red Sand Beach", image:"image5")
]
