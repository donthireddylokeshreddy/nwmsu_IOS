//
//  ViewController.swift
//  Donthireddy_WordGuess
//
//  Created by Donthireddy,Lokeshreddy on 3/29/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var wordGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var PAButton: UIButton!
        
        @IBOutlet weak var guessButton: UIButton!
        
    
        
    @IBOutlet weak var dispImage: UIImageView!
    
    
    var NoofGuess = 0
        var x=0
        var guessedwords=""
        var letguessed = ""
        var xChange=false
        var image_ = [["TEMPLE","hindu important place", "temple"],["CHENNAI","A place where all tourists enjoy in beaches","chennai"],["MODI","pm of india","modi"],["JAGAN","young cm in india","jagan"],["KCR","good cm ","kcr"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        wordGuessedLabel.text!+="0"
                wordsRemainingLabel.text!+="5"
                totalWordsLabel.text!+="5"
                hintLabel.text="Hint : "+image_[x][1]
                statusLabel.text=""
                PAButton.isHidden=true
                userGuessLabel.text=""
                guessButton.isEnabled=false
                guessedwords = image_[x][0]
                UnderScores()
    }

    
    @IBAction func guessLetterButtonPressed(_ sender: Any) {
        
        if(NoofGuess != 10){
                    NoofGuess+=1
                    guessCountLabel.text="You have made \(NoofGuess) guesses"
                    var letter = guessLetterField.text!
                    
                    //Replace the guessed letter if the letter is part of the word.
                    letguessed = letguessed + letter
                     var revealedWord = ""
                    for l in guessedwords{
                        if letguessed.contains(l){
                            revealedWord += "\(l)"
                        }
                        else{
                            revealedWord += "_ "
                        }
                    }
                    //Assigning the word to displaylabel after a guess
                    userGuessLabel.text = revealedWord
                    guessLetterField.text = ""
                    
                    //If the word is guessed correctly, we are enabling play again button and disabling the check button.
                    if userGuessLabel.text!.contains("_") == false{
                        PAButton.isHidden = false;
                        dispImage.image=UIImage(named: image_[x][2])
                        guessButton.isEnabled = false;
                        guessCountLabel.text="Wow! You have made \(NoofGuess) guesses to guess the word!"
                        wordGuessedLabel.text="Total number of words guessed successfully : \(x+1)"
                        wordsRemainingLabel.text="Total number of words remaining in game : \(image_.count-(x+1))"
                        
                    }
                    guessButton.isEnabled = false
                    xChange=true
                }else{
                    hintLabel.text=""
                    PAButton.isHidden=false
                    guessCountLabel.text="You have used all the available guesses, Please play Again"
                    xChange=false
                }
        
    }
    
    
    @IBAction func playAgainButtonPressed(_ sender: Any) {
        
        if(xChange){
                    x += 1
                }else{
                    
                }
                guessLetterField.text=""
                PAButton.isHidden = true
                dispImage.image=UIImage()
                guessButton.isEnabled=false
                NoofGuess=0
                guessCountLabel.text="You have made \(NoofGuess) guesses"
                //clear the label
                letguessed = ""
                
                //if count reaches the end of the array (all the words are guessed sucessfully), then print Congratualtions in the status label.
                if x+1 == image_.count+1{
                    guessCountLabel.text=""
                    dispImage.image=UIImage(named: "done")
                    statusLabel.text = "Congruations! You are done with the game! Please Start over agian"
                    //clearing the labels.
                    userGuessLabel.text = ""
                    hintLabel.text = ""
                }
                else{
                    //fetch the next word from the array
                    guessedwords = image_[x][0]
                    //fetch the hint related to the word
                    hintLabel.text = "Hint: "+image_[x][1]
                    //Enabling the check button.
                    guessButton.isEnabled = true
                    
                    userGuessLabel.text = ""
                    UnderScores()
                }
        
    }
    
   
    @IBAction func TextEntered(_ sender: Any) {
        
               
                //Read the data from the text field
                var character = guessLetterField.text!;
                
                character = String(character.last ?? " ").trimmingCharacters(in: .whitespaces)
                guessLetterField.text = character
                
                //Check whether the entered text is empty or not to enable check button.
                if character.isEmpty{
                    guessButton.isEnabled = false
                }
                else{
                    guessButton.isEnabled = true
                }
    }
    
    func UnderScores(){
            for character in guessedwords{
                userGuessLabel.text!+="_ "
            }
        }
}

