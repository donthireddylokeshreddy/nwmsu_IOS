//
//  ViewController.swift
//  Donthireddy_UniversityApp
//
//  Created by Donthireddy,Lokeshreddy on 4/19/23.
//

import UIKit

class UniversitiesViewController:UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var c_list = array_course
    
    
    @IBOutlet weak var universitiesTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        universitiesTableView.delegate = self
        universitiesTableView.dataSource = self
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
          let transition = segue.identifier
          if transition == "listsSegue"{
              let destination = segue.destination as!  UniversityListViewController
              destination.view_title = c_list[(universitiesTableView.indexPathForSelectedRow?.row)!].domain
              destination.universities_List = c_list[(universitiesTableView.indexPathForSelectedRow?.row)!].list_Array
          }
      }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return c_list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = universitiesTableView.dequeueReusableCell(withIdentifier: "domainCell", for: indexPath)
        cell.textLabel?.text = c_list[indexPath.row].domain
        return cell
    }
    
    
}
