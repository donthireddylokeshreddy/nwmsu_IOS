//
//  UniversityInfoViewController.swift
//  Donthireddy_UniversityApp
//
//  Created by Donthireddy,Lokeshreddy on 4/19/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {
    
    
    @IBOutlet weak var universtiesimageview: UIImageView!
    
    @IBOutlet weak var univertiesinfooutlet: UITextView!
    
    var universityImage = ""
    var universityData = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = universityImage
        let picture = UIImageView(image: UIImage(named: universityImage))
        picture.frame = CGRect(x: 195, y: 183, width: 240, height: 150)
        view.addSubview(picture)
        // Animate the image view's position from left to right
        UIView.animate(withDuration: 1.5, animations: {
            picture.frame.origin.x -= 120
        })

        
    }
    
    @IBAction func uniInfoBtn(_ sender: Any) {
        univertiesinfooutlet.text = universityData
    }
    
}
