//
//  Universities.swift
//  Donthireddy_UniversityApp
//
//  Created by Donthireddy,Lokeshreddy on 4/19/23.
//

import Foundation
struct Universities{
    var domain = ""
    var list_Array:[UniversityList] = []
}

struct UniversityList{
    var collegeName = ""
    var collegeImage = ""
    var collegeInfo = ""
}

var cincinnati = "University of Cincinnati"
var cincinnatiImage="cincinnati"
var cincinnatiInfo = "The University of Cincinnati is a public research university in Cincinnati, Ohio. Founded in 1819 as Cincinnati College, it is the oldest institution of higher education in Cincinnati and has an annual enrollment of over 44,000 students, making it the second largest university in Ohio"
var clark = "Clark University"
var clarkImage="clark"
var clarkInfo = "First established in 1887 in Worcester, Massachusetts, Clark University is notable for being one of the original large-scale research institutes in the country. Clark keeps true to its mission with its numerous research-based science programs. In addition to the sciences, there are over 40 diverse areas of study."
var centralMissouri = "University of Central Missouri"
var centralMissouriImage="centralmissouri"
var centralMissouriInfo = "The University of Central Missouri is a public university in Warrensburg, Missouri. In 2019, enrollment was 11,229 students from 49 states and 59 countries on its 1,561-acre campus. UCM offers 150 programs of study, including 10 pre-professional programs, 27 areas of teacher certification, and 37 graduate programs."
var newyork = "University of New York"
var newyorkImage="newyork"
var newyorkInfo = "New York University is a private research university in New York City. Chartered in 1831 by the New York State Legislature, NYU was founded by a group of New Yorkers led by then–Secretary of the Treasury Albert Gallatin."
var depaul = "University of De Paul"
var depaulImage="depaul"
var depaulInfo = "DePaul University does not discriminate on the basis of race, color, ethnicity, religion, sex, gender, gender identity, sexual orientation, national origin, age, marital status, pregnancy, parental status, family relationship status, physical or mental disability, military status, genetic information or other status protected by local, state or federal law in matters of admissions, employment, housing, scholarships, loans, athletics and other school-administered programs. Individuals who believe they have been subjected to discrimination, harassment or retaliation are encouraged to report what happened"
var arlington = "University of Arlington"
var arlingtonImage="arlington"
var arlingtonInfo = "The University of Texas at Arlington is a public research university in Arlington, Texas. The university was founded in 1895 and was in the Texas A&M University System for several decades until joining the University of Texas System in 1965. "
var southcaroloina = "University of South Carolina"
var southcaroloinaImage="southcarolina"
var southcaroloinaInfo = "The University of South Carolina is a public research university in Columbia, South Carolina. It is the flagship of the University of South Carolina System and the largest university in the state by enrollment. Its main campus is on over 359 acres in downtown Columbia, close to the South Carolina State House."
var memphis = "Memphis State University"
var memphisImage="memphis"
var memphisInfo = "The University of Memphis (UofM) is a public research university in Memphis, Tennessee. Founded in 1912, the university has an enrollment of more than 22,000 students."
var boston = "University of Boston"
var bostonImage="boston"
var bostonInfo = "Boston University requires you to be above average in your high school class. You'll need a mix of A's and B's, with a leaning toward A's. If you took some AP or IB classes, this will help boost your weighted GPA and show your ability to take college classes."
var atlanta = "Atlanta State University"
var atlantaImage="Atlanta"
var atlantaInfo = "Atlanta University—now Clark Atlanta University—is the first HBCU in the Southern United States, and the nation's oldest graduate institution serving a predominantly African-American student body. It was chartered on October 17, 1867. It offered its first instruction at the postsecondary level in 1869."
var stanford = "Stanford University"
var stanfordImage="stanford"
var stanfordInfo = "Stanford University, officially Leland Stanford Junior University, is a private research university in Stanford, California. The campus occupies 8,180 acres, among the largest in the United States, and enrolls over 17,000 students."
 
let Domains=["Information Technology","Computer Science","Data Science And Analytics","Cyber Security"]

let d1 = Universities(domain: Domains[3],list_Array: [UniversityList(collegeName: cincinnati,collegeImage: cincinnatiImage,collegeInfo: cincinnatiInfo),UniversityList(collegeName: clark,collegeImage: clarkImage,collegeInfo: clarkInfo),UniversityList(collegeName: centralMissouri,collegeImage: centralMissouriImage,collegeInfo: centralMissouriInfo),UniversityList(collegeName: newyork,collegeImage: newyorkImage,collegeInfo: newyorkInfo),UniversityList(collegeName: depaul,collegeImage: depaulImage,collegeInfo: depaulInfo),UniversityList(collegeName: arlington,collegeImage: arlingtonImage,collegeInfo: arlingtonInfo)])

let d2 = Universities(domain: Domains[0],list_Array: [UniversityList(collegeName: southcaroloina,collegeImage: southcaroloinaImage,collegeInfo: southcaroloinaInfo),UniversityList(collegeName: cincinnati,collegeImage: cincinnatiImage,collegeInfo: cincinnatiInfo),UniversityList(collegeName: memphis,collegeImage: memphisImage,collegeInfo: memphisInfo),UniversityList(collegeName: boston,collegeImage: bostonImage,collegeInfo: bostonInfo),UniversityList(collegeName: atlanta,collegeImage: atlantaImage,collegeInfo: atlantaInfo),UniversityList(collegeName: stanford,collegeImage: stanfordImage,collegeInfo: stanfordInfo)])

let d3 = Universities(domain: Domains[1],list_Array: [UniversityList(collegeName: cincinnati,collegeImage: cincinnatiImage,collegeInfo: cincinnatiInfo),UniversityList(collegeName: boston,collegeImage: bostonImage,collegeInfo: bostonInfo),UniversityList(collegeName: memphis,collegeImage: memphisImage,collegeInfo: memphisInfo),UniversityList(collegeName: arlington,collegeImage: arlingtonImage,collegeInfo: arlingtonInfo),UniversityList(collegeName: newyork,collegeImage: newyorkImage,collegeInfo: newyorkInfo),UniversityList(collegeName: centralMissouriImage,collegeImage: centralMissouriImage,collegeInfo: centralMissouriInfo)])

let d4 = Universities(domain: Domains[2],list_Array: [UniversityList(collegeName: cincinnati,collegeImage: cincinnatiImage,collegeInfo: cincinnatiInfo),UniversityList(collegeName: centralMissouri,collegeImage: centralMissouriImage,collegeInfo: centralMissouriInfo),UniversityList(collegeName: southcaroloina,collegeImage: southcaroloinaImage,collegeInfo: southcaroloinaInfo),UniversityList(collegeName: depaul,collegeImage: depaulImage,collegeInfo: depaulInfo),UniversityList(collegeName: boston,collegeImage: bostonImage,collegeInfo: bostonInfo)])
                               
                               
let array_course = [d1,d2,d3,d4]
