//
//  UniversityListViewController.swift
//  Donthireddy_UniversityApp
//
//  Created by Donthireddy,Lokeshreddy on 4/19/23.
//

import UIKit

class UniversityListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var universityListTableView: UITableView!
    
    var universities_List:[UniversityList]=[]
    var view_title = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = view_title
        universityListTableView.delegate = self
        universityListTableView.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return universities_List.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = universityListTableView.dequeueReusableCell(withIdentifier:"listCell", for: indexPath)
        cell.textLabel?.text = universities_List[indexPath.row].collegeName
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
          let transition = segue.identifier
          if transition == "universityInfoSegue"{
              let destination = segue.destination as!  UniversityInfoViewController
              destination.universityData = universities_List[(universityListTableView.indexPathForSelectedRow?.row)!].collegeInfo
              destination.universityImage = universities_List[(universityListTableView.indexPathForSelectedRow?.row)!].collegeImage
          }
      }
    


}
